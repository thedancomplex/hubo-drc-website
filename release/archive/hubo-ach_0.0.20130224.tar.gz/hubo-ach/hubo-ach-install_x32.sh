sudo mkdir /var/log/hubo/
sudo mkdir /var/lock/hubo/
./configure --build=i686-pc-linux-gnu "CFLAGS=-m32" "CXXFLAGS=-m32" "LDFLAGS=-m32"
sudo make clean
make
sudo make install
sudo updatedb
