debuild -us -uc
