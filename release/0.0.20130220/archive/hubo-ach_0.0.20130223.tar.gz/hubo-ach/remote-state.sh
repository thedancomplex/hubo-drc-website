hubo-ach make
sudo chmod 777 /dev/shm/achshm-hubo*
achd -r pull 192.168.0.25 hubo-state
