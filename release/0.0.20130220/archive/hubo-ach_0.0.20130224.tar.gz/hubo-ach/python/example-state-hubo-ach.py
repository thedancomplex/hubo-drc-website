#!/usr/bin/env python
import hubo_ach
import ach
import time
import os
ha = hubo_ach

def cls():
    os.system(['clear','cls'][os.name == 'nt'])

c = ach.Channel(ha.HUBO_CHAN_STATE_NAME)
c.flush()
b = ha.HUBO_STATE()

while(1):
    [status, framesize] = c.get(b, wait=True, last=False)
    if status == ach.ACH_OK or status == ach.ACH_MISSED_FRAME:
        cls()
        print "state = ", status, "  Frme Size = ", framesize
        for i in range(0,ha.HUBO_JOINT_COUNT):
            print i, " : ", b.joint[i].ref
    else:
        raise ach.AchException( c.result_string(status) )
    time.sleep(0.1)
c.close()

