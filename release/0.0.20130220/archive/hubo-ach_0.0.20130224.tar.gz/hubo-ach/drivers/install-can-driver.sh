sudo apt-get install linux-headers-$(uname -r)
cd ~/
tar -xzf peak-linux-driver-7.8.tar.gz
cd peak-linux-driver-7.8
cat /lib/modules/$(uname -r)/build/include/linux/version.h
sudo make clean
sudo make
sudo make install
sudo /sbin/modprobe pcan
