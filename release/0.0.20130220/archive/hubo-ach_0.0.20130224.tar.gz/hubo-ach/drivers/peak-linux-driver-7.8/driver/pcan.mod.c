#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x5eadf54a, "module_layout" },
	{ 0x173a8e5, "pcmcia_dev_present" },
	{ 0x6bc3fbc0, "__unregister_chrdev" },
	{ 0x1fedf0f4, "__request_region" },
	{ 0x85e90336, "kmalloc_caches" },
	{ 0x12da5bb2, "__kmalloc" },
	{ 0xb1d1cffe, "pcmcia_enable_device" },
	{ 0x349cba85, "strchr" },
	{ 0x69a358a6, "iomem_resource" },
	{ 0xd0d8621b, "strlen" },
	{ 0xeaa96952, "dev_set_drvdata" },
	{ 0xf0b27fa0, "pcmcia_register_driver" },
	{ 0x99f7387e, "usb_init_urb" },
	{ 0xc8b57c27, "autoremove_wake_function" },
	{ 0x6e4fbe20, "usb_reset_endpoint" },
	{ 0x38dd7f9f, "pci_disable_device" },
	{ 0x5232fbb9, "i2c_transfer" },
	{ 0x20000329, "simple_strtoul" },
	{ 0x6c917205, "usb_kill_urb" },
	{ 0xd85bcbe4, "usb_deregister_dev" },
	{ 0x59528ec6, "remove_proc_entry" },
	{ 0x21a21ea4, "device_destroy" },
	{ 0xc5c383c, "usb_reset_configuration" },
	{ 0xb37617ec, "parport_find_base" },
	{ 0x1697b269, "__register_chrdev" },
	{ 0x289a8d2c, "driver_for_each_device" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0xfb0e29f, "init_timer_key" },
	{ 0x6baae653, "cancel_delayed_work_sync" },
	{ 0xe2079de4, "pci_bus_write_config_word" },
	{ 0x91715312, "sprintf" },
	{ 0xe2746bc1, "pcmcia_request_io" },
	{ 0x7d11c268, "jiffies" },
	{ 0x42202b82, "netif_rx" },
	{ 0x48eb0c0d, "__init_waitqueue_head" },
	{ 0x72aa82c6, "param_ops_charp" },
	{ 0xd5f2172f, "del_timer_sync" },
	{ 0x2bc95bd4, "memset" },
	{ 0xff7559e4, "ioport_resource" },
	{ 0x4f89ee0c, "dev_alloc_skb" },
	{ 0xf97456ea, "_raw_spin_unlock_irqrestore" },
	{ 0x131ff057, "current_task" },
	{ 0x70d1f8f3, "strncat" },
	{ 0x37befc70, "jiffies_to_msecs" },
	{ 0xedd01cf1, "usb_deregister" },
	{ 0x50eedeb8, "printk" },
	{ 0x42224298, "sscanf" },
	{ 0x68138f00, "parport_unregister_device" },
	{ 0x93e07260, "usb_set_interface" },
	{ 0x18f64c13, "free_netdev" },
	{ 0xb6ed1e53, "strncpy" },
	{ 0x2f287f0d, "copy_to_user" },
	{ 0xe42cc6e1, "register_netdev" },
	{ 0xb4390f9a, "mcount" },
	{ 0x4c940300, "usb_register_dev" },
	{ 0xf06b9b5, "usb_control_msg" },
	{ 0x6c2e3320, "strncmp" },
	{ 0x16305289, "warn_slowpath_null" },
	{ 0xf1faf509, "device_create" },
	{ 0xbe2c0274, "add_timer" },
	{ 0x5fbdf89a, "parport_claim" },
	{ 0x2072ee9b, "request_threaded_irq" },
	{ 0xfeb25c8f, "pcmcia_loop_config" },
	{ 0x71960005, "init_net" },
	{ 0x2fa73093, "parport_release" },
	{ 0xf42017ea, "i2c_del_adapter" },
	{ 0xa8a6f639, "__check_region" },
	{ 0xa1623c00, "usb_submit_urb" },
	{ 0x42c8de35, "ioremap_nocache" },
	{ 0x3a2c8da1, "pci_bus_read_config_word" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x884eebb3, "usb_reset_device" },
	{ 0x77edf722, "schedule_delayed_work" },
	{ 0x6d916f2c, "parport_register_device" },
	{ 0x4292364c, "schedule" },
	{ 0xd62c833f, "schedule_timeout" },
	{ 0x86a4889a, "kmalloc_order_trace" },
	{ 0x367cf52b, "usb_clear_halt" },
	{ 0x29eed280, "alloc_netdev_mqs" },
	{ 0x7e1805b7, "create_proc_entry" },
	{ 0x7c61340c, "__release_region" },
	{ 0x7f54e718, "pci_unregister_driver" },
	{ 0x88160a7b, "__dev_get_by_name" },
	{ 0x83699014, "kmem_cache_alloc_trace" },
	{ 0x21fb443e, "_raw_spin_lock_irqsave" },
	{ 0x34f9e73, "param_ops_byte" },
	{ 0xe45f60d8, "__wake_up" },
	{ 0xf6ebc03b, "net_ratelimit" },
	{ 0x1d2e87c6, "do_gettimeofday" },
	{ 0x37a0cba, "kfree" },
	{ 0x2e60bace, "memcpy" },
	{ 0x622fa02a, "prepare_to_wait" },
	{ 0xf59f197, "param_array_ops" },
	{ 0xedc03953, "iounmap" },
	{ 0xfdbfd1b0, "pcmcia_unregister_driver" },
	{ 0x212cb78e, "__pci_register_driver" },
	{ 0x9330ff56, "usb_register_driver" },
	{ 0xf62d269d, "class_destroy" },
	{ 0x75bb675a, "finish_wait" },
	{ 0x561bc67, "unregister_netdev" },
	{ 0xdb4acf4b, "i2c_bit_add_bus" },
	{ 0xb81960ca, "snprintf" },
	{ 0xb703ea3c, "__netif_schedule" },
	{ 0x8235805b, "memmove" },
	{ 0x6194b31c, "consume_skb" },
	{ 0x8436f8e3, "param_ops_ushort" },
	{ 0xf566c55d, "pcmcia_disable_device" },
	{ 0x1795e732, "skb_put" },
	{ 0x6468ccc, "pci_enable_device" },
	{ 0x362ef408, "_copy_from_user" },
	{ 0xd6e17aa6, "__class_create" },
	{ 0xb5f50765, "dev_get_drvdata" },
	{ 0xf20dabd8, "free_irq" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=pcmcia,parport,i2c-algo-bit";

MODULE_ALIAS("usb:v0C72p000Cd*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0C72p000Dd*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("pci:v0000001Cd00000001sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000001Cd00000003sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000001Cd00000004sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000001Cd00000005sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000001Cd00000006sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000001Cd00000007sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000001Cd00000008sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000001Cd00000002sv*sd*bc*sc*i*");
MODULE_ALIAS("pcmcia:m0377c0001f*fn*pfn*pa*pb*pc*pd*");

MODULE_INFO(srcversion, "B1562E2BD4D8DDB2B15E18A");
